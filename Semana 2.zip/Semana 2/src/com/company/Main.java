package com.company;
import javax.swing.JOptionPane;

public class Main
{

    public static void main(String[] args)
    {

       /* int nota;
        nota = Integer.parseInt(JOptionPane.showInputDialog(null,"Ingrese un numero"));
        if (nota >= 800){
            JOptionPane.showMessageDialog(null, "De acuerdo a su puntaje puede elegir las siguientes carreras: Medicina, Informatica, Enfermeria");
        } else {
            JOptionPane.showMessageDialog(null," Solo puede escoger carreras tecnicas");
        }*/

         /* int Edad;
        Edad = Integer.parseInt(JOptionPane.showInputDialog(null,"Hola. ingrese su edad"));
        if (Edad >= 18)
        {
            JOptionPane.showMessageDialog(null, "Usted puede votar");
        } else
        {
            JOptionPane.showMessageDialog(null, "Usted no puede votar");

        }*/



       /*  int provincia;
         provincia = Integer.parseInt(JOptionPane.showInputDialog(null,"Hola. ingrese la provincia donde vive: \n \n 1.San José \n 2.Alajuela \n 3.Heredia \n 4.Cartago \n 5.Limon \n 6. Guanacaste \n Puntarenas" ));
         if (provincia ==1);
         {
         JOptionPane.showMessageDialog(null, "Usted vive en San José");
         }
         else if (provincia==2)
         {
             JOptionPane.showMessageDialog(null, "Usted vive en Alajuela");
         }
         else if (provincia==3)
        {
        JOptionPane.showMessageDialog(null, "Usted vive en Heredia");
        }
         else if (provincia==4)
        {
        JOptionPane.showMessageDialog(null, "Usted vive en Cartago");
        }
         else if (provincia==5)
        {
        JOptionPane.showMessageDialog(null, "Usted vive en Limon");
        }

       else if (provincia==6)
       {
        JOptionPane.showMessageDialog(null, "Usted vive en Guanacaste");
       }
       else
       {
           JOptionPane.showMessageDialog(null, "Usted vive en Puntarenas ");

        */


        int dia;
        dia = Integer.parseInt(JOptionPane.showInputDialog(null,"!ingrese el dia de hoy: \n \n 1.lunes \n 2.Martes  \n 3.Miercoles \n 4.Jueves \n 5.Viernes \n 6. Sabado \n Domingo" ));
        if ( dia==1)
        {
            JOptionPane.showMessageDialog(null, "Lunes, dia laboral");
        }
        else if ( dia==2)
        {
            JOptionPane.showMessageDialog(null, "Martes, dia laboral");
        }
        else if ( dia==3)
        {
            JOptionPane.showMessageDialog(null, "Miercoles, dia laboral");
        }
        else if ( dia==4)
        {
            JOptionPane.showMessageDialog(null, "Jueves, dia laboral");

        }
        else if ( dia==5)
        {
            JOptionPane.showMessageDialog(null, "Viernes, dia laboral");

        }
        else if ( dia==6)
        {
            JOptionPane.showMessageDialog(null, "Sabado, no es dia laboral");

        }
        else
        {
            JOptionPane.showMessageDialog(null, "Domingo, no es dia laboral");

        }
    }

}








