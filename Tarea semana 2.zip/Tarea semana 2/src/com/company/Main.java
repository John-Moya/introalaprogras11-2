package com.company;
import javax.swing.JOptionPane;

public class Main
{

    public static void main(String[] args)
    {

     int añosdeAntiguedad;
     int horaslaboradas;
     double pagaporHora;
     double salarioBruto;
     double bono;
     double salarioNuevo;
     double deduccion;
     double salarioNeto;

        añosdeAntiguedad = Integer.parseInt(JOptionPane.showInputDialog("Digite los años de antiguedad con la empresa"));
        horaslaboradas = Integer.parseInt(JOptionPane.showInputDialog("Digite la cantidad de horas laboradas para la empresa"));
        pagaporHora = Integer.parseInt(JOptionPane.showInputDialog("Digite la cantidad que se le paga por hora"));

       salarioBruto = (horaslaboradas*pagaporHora);
       if (añosdeAntiguedad > 10)
       {
         bono = (salarioBruto*0.20);
       }
       else
       {
          bono = 0;
       }
        salarioNuevo = (salarioBruto+bono);

       if (salarioNuevo > 1000)
       {
           deduccion = (salarioNuevo-0.10);
       }
       else if (salarioNuevo > 2000)
        {
            deduccion = (salarioNuevo-0.15);
        }
        else
        {
            deduccion = 0;
        }

        salarioNeto = (salarioNuevo-deduccion);


        JOptionPane.showMessageDialog(null,"Su salario neto es de "+salarioNeto);


    }
}
